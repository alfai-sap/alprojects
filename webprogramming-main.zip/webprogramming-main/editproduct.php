<?php

// Include the necessary files for utility functions and the Product class.
require_once('functions.php');
require_once('product.class.php');

// Initialize variables to hold form input values and error messages.
$code = $name = $category = $price ='';
$codeErr = $nameErr = $categoryErr = $priceErr ='';
$inStock = $outStock = $stockInInput = $stockOutInput = '';
$productObj = new Product(); // Initialize the Product object

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Handle GET request to fetch and display the product details for editing.
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $record = $productObj->fetchRecord($id); // Fetch product details by ID
        $stockRecord = $productObj->fetchStock($id); // Fetch stock details by product ID
        if (!empty($record)) {
            // Populate form fields with existing product details for editing.
            $code = $record['code'];
            $name = $record['name'];
            $category = $record['category_id'];
            $price = $record['price'];
            $inStock = $stockRecord['in_quantity'];
            $outStock = $stockRecord['out_quantity'];
        } else {
            echo 'No product found';
            exit;
        }
    } else {
        echo 'No product found';
        exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle POST request to update the product details.

    // Clean and assign the input values to variables using the clean_input function.
    $id = clean_input($_GET['id']);
    $code = clean_input($_POST['code']);
    $name = clean_input($_POST['name']);
    $category = clean_input($_POST['category']);
    $price = clean_input($_POST['price']);
    $stockInInput = clean_input($_POST['stock_in']);
    $stockOutInput = clean_input($_POST['stock_out']);

    // Validate the 'code' field.
    if (empty($code)) {
        $codeErr = 'Product Code is required';
    } else if ($productObj->codeExists($code, $id)) { // Ensure the code is unique for other products.
        $codeErr = 'Product Code already exists';
    }

    // Validate the 'name' field.
    if (empty($name)) {
        $nameErr = 'Name is required';
    }

    // Validate the 'category' field.
    if (empty($category)) {
        $categoryErr = 'Category is required';
    }

    // Validate the 'price' field.
    if (empty($price)) {
        $priceErr = 'Price is required';
    } elseif (!is_numeric($price)) {
        $priceErr = 'Price should be a number';
    } elseif ($price < 1) {
        $priceErr = 'Price must be greater than 0';
    }

    // Validate 'stock_in' and 'stock_out' fields for numeric input
    if (!empty($stockInInput) && !is_numeric($stockInInput)) {
        $stockErr = 'Stock-In should be a number';
    }
    if (!empty($stockOutInput) && !is_numeric($stockOutInput)) {
        $stockErr = 'Stock-Out should be a number';
    }

    // If there are no validation errors, proceed to update the product in the database.
    if (empty($codeErr) && empty($nameErr) && empty($priceErr) && empty($categoryErr)) {
        // Set the product properties.
        $productObj->id = $id;
        $productObj->code = $code;
        $productObj->name = $name;
        $productObj->category_id = $category;
        $productObj->price = $price;

        // Try to update the product in the database.
        if ($productObj->edit()) {
            // Update stock quantities
            $productObj->updateStock($id, $stockInInput, $stockOutInput);
            
            // If successful, redirect to the product list page.
            header('Location: product.php');
        } else {
            // If there's an issue, display an error message.
            echo 'Something went wrong when updating the product';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <style>
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <!-- Form to collect product details for editing -->
    <form action="?id=<?= $id ?>" method="post"> <!-- Pass the id in the form action -->

        <!-- Display a note indicating required fields -->
        <span class="error">* are required fields</span>
        <br>

        <!-- Code field with validation error display -->
        <label for="code">Code</label><span class="error">*</span>
        <br>
        <input type="text" name="code" id="code" value="<?= $code ?>"> <!-- Retain entered values -->
        <br>
        <?php if (!empty($codeErr)): ?>
            <span class="error"><?= $codeErr ?></span><br>
        <?php endif; ?>

        <!-- Name field with validation error display -->
        <label for="name">Name</label><span class="error">*</span>
        <br>
        <input type="text" name="name" id="name" value="<?= $name ?>"> <!-- Retain entered values -->
        <br>
        <?php if (!empty($nameErr)): ?>
            <span class="error"><?= $nameErr ?></span><br>
        <?php endif; ?>

        <!-- Category dropdown with validation error display -->
        <label for="category">Category</label><span class="error">*</span>
        <br>
        <select name="category" id="category">
            <option value="">--Select--</option>
            <?php
                $categoryList = $productObj->fetchCategory();
                foreach ($categoryList as $cat){
            ?>
                <option value="<?= $cat['id'] ?>" <?= ($category == $cat['id']) ? 'selected' : '' ?>><?= $cat['name'] ?></option>
            <?php
                }
            ?>
        </select>
        <br>
        <?php if (!empty($categoryErr)): ?>
            <span class="error"><?= $categoryErr ?></span><br>
        <?php endif; ?>

        <!-- Price field with validation error display -->
        <label for="price">Price</label><span class="error">*</span>
        <br>
        <input type="number" name="price" id="price" value="<?= $price ?>"> <!-- Retain entered values -->
        <br>
        <?php if (!empty($priceErr)): ?>
            <span class="error"><?= $priceErr ?></span>
            <br>
        <?php endif; ?>

        <!-- Current Stock Information (Non-Editable Fields) -->
        <label>Current In-Stock Quantity:</label>
        <input type="text" value="<?= $inStock ?>" readonly>
        <br>

        <label>Current Out-Stock Quantity:</label>
        <input type="text" value="<?= $outStock ?>" readonly>
        <br>

        <!-- Stock-In Input Field -->
        <label for="stock_in">Stock-In Quantity</label>
        <input type="number" name="stock_in" id="stock_in" value= <?= $stockInInput ?>>
        <br>

        <!-- Stock-Out Input Field -->
        <label for="stock_out">Stock-Out Quantity</label>
        <input type="number" name="stock_out" id="stock_out" value= <?= $stockOutInput ?>>
        <br>

        <!-- Submit button -->
        <br>
        <input type="submit" value="Update Product">
    </form>
</body>
</html>
